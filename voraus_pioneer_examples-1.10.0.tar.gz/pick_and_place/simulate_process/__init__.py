"""Contains the simulate process example."""
