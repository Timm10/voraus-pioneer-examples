"""Contains the simulate gripper example."""
